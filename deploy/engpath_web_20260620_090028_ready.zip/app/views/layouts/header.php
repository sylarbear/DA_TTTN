<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="EngPath - nền tảng học tiếng Anh theo lộ trình, tích hợp từ vựng, bài học, kiểm tra và luyện nói AI.">
    <title><?= $title ?? APP_NAME ?></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300..800&family=Be+Vietnam+Pro:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/components.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/pages.css?v=<?= time() ?>">
</head>
<body>
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="<?= BASE_URL ?>" class="nav-logo">
                <span class="brand-mark"><i class="fas fa-route"></i></span>
                <span><?= APP_NAME ?></span>
            </a>

            <button class="nav-toggle" id="navToggle" aria-label="Mở menu">
                <span></span><span></span><span></span>
            </button>

            <ul class="nav-menu" id="navMenu">
                <?php if (Middleware::isAdmin()): ?>
                    <li><a href="<?= BASE_URL ?>/admin" class="nav-link"><i class="fas fa-gauge-high"></i> Admin</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/users" class="nav-link"><i class="fas fa-users"></i> Users</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/topics" class="nav-link"><i class="fas fa-book-open"></i> Khóa học</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/questions" class="nav-link"><i class="fas fa-circle-question"></i> Câu hỏi</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/orders" class="nav-link"><i class="fas fa-file-invoice-dollar"></i> Đơn</a></li>
                    <li><a href="<?= BASE_URL ?>/admin/tickets" class="nav-link"><i class="fas fa-headset"></i> Hỗ trợ</a></li>
                    <li><a href="<?= BASE_URL ?>/auth/logout" class="nav-link btn-login"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a></li>
                <?php else: ?>
                    <li><a href="<?= BASE_URL ?>" class="nav-link"><i class="fas fa-home"></i> Trang chủ</a></li>
                    <li><a href="<?= BASE_URL ?>/topic" class="nav-link"><i class="fas fa-book-open"></i> Khóa học</a></li>
                    <li><a href="<?= BASE_URL ?>/test" class="nav-link"><i class="fas fa-clipboard-check"></i> Bài test</a></li>
                    <li><a href="<?= BASE_URL ?>/speaking" class="nav-link"><i class="fas fa-microphone"></i> Luyện nói</a></li>
                    <li><a href="<?= BASE_URL ?>/membership" class="nav-link"><i class="fas fa-crown"></i> Pro</a></li>

                    <?php if (Middleware::isLoggedIn()): ?>
                        <li class="nav-more">
                            <button class="nav-link nav-more-btn" id="navMoreBtn"><i class="fas fa-border-all"></i> Thêm <i class="fas fa-chevron-down" style="font-size:0.65rem;"></i></button>
                            <div class="nav-more-menu" id="navMoreMenu">
                                <a href="<?= BASE_URL ?>/dashboard"><i class="fas fa-chart-line"></i> Dashboard</a>
                                <a href="<?= BASE_URL ?>/grammar"><i class="fas fa-graduation-cap"></i> Ngữ pháp</a>
                                <a href="<?= BASE_URL ?>/leaderboard"><i class="fas fa-trophy"></i> Xếp hạng</a>
                                <a href="<?= BASE_URL ?>/bookmark"><i class="fas fa-bookmark"></i> Từ đã lưu</a>
                                <a href="<?= BASE_URL ?>/topic/search"><i class="fas fa-search"></i> Tìm kiếm</a>
                                <a href="<?= BASE_URL ?>/support"><i class="fas fa-headset"></i> Hỗ trợ</a>
                                <a href="<?= BASE_URL ?>/wallet"><i class="fas fa-wallet"></i> Ví của tôi</a>
                                <?php if (!Middleware::isPro()): ?>
                                    <a href="<?= BASE_URL ?>/membership" class="nav-more-upgrade"><i class="fas fa-crown"></i> Nâng cấp Pro</a>
                                <?php endif; ?>
                            </div>
                        </li>

                        <li class="nav-user">
                            <div class="user-dropdown">
                                <button class="user-btn" id="userDropdownBtn">
                                    <i class="fas fa-user-circle"></i>
                                    <span><?= htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']) ?></span>
                                    <?php if (Middleware::isPro()): ?>
                                        <span class="nav-pro-badge">PRO</span>
                                    <?php endif; ?>
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                                <div class="dropdown-menu" id="userDropdown">
                                    <a href="<?= BASE_URL ?>/profile"><i class="fas fa-user"></i> Hồ sơ cá nhân</a>
                                    <a href="<?= BASE_URL ?>/membership"><i class="fas fa-crown"></i> <?= Middleware::isPro() ? 'Quản lý Pro' : 'Nâng cấp Pro' ?></a>
                                    <a href="<?= BASE_URL ?>/auth/logout"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
                                </div>
                            </div>
                        </li>
                    <?php else: ?>
                        <li><a href="<?= BASE_URL ?>/auth/login" class="nav-link btn-login"><i class="fas fa-sign-in-alt"></i> Đăng nhập</a></li>
                        <li><a href="<?= BASE_URL ?>/auth/register" class="nav-link btn-register"><i class="fas fa-user-plus"></i> Học miễn phí</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <?php if (isset($_SESSION['flash'])): ?>
        <div class="flash-message flash-<?= $_SESSION['flash']['type'] ?>" id="flashMessage">
            <div class="flash-content">
                <?php if ($_SESSION['flash']['type'] === 'success'): ?>
                    <i class="fas fa-check-circle"></i>
                <?php elseif ($_SESSION['flash']['type'] === 'error'): ?>
                    <i class="fas fa-exclamation-circle"></i>
                <?php else: ?>
                    <i class="fas fa-info-circle"></i>
                <?php endif; ?>
                <span><?= htmlspecialchars($_SESSION['flash']['message']) ?></span>
                <button class="flash-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <?php unset($_SESSION['flash']); ?>
    <?php endif; ?>

    <main class="main-content">
